# LEAD_SCORING_MATRIX
> Algorithm to rank sales leads.

## SPECS
- **Technology:** Python
- **License:** Sovereign/Commercial
- **Version:** 1.0

## INSTALLATION
1. Extract contents.
2. Follow the specific guide in `PROTOCOL.md`.

**SYSTEM SECURE.**
