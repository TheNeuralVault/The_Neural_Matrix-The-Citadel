# INTERNAL_NEURAL_NET

Running Protocol v1.0

## USAGE
Execute the main script.

TYPE: ENTERPRISE