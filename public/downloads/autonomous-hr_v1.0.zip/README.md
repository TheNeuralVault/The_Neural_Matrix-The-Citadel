# AUTONOMOUS_HR

Running Protocol v1.0

## USAGE
Execute the main script.

TYPE: BUSINESS